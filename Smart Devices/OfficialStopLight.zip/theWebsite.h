const char websiteCode[] PROGMEM = R"=====(
<!DOCTYPE html>
<!DOCTYPE html>
<style>
    body{
        background:#bda5a4; 
        display: flex; 
        align-items: center; 
        justify-content: center; 
        min-height: 100vh;
    }
</style>

<html>
    <body>
        <center>
            <h1>Temporary Traffic Stop Light Controls</h1>
            <h4>
                <a href="redLightOn"><input type="button" value="redLight ON" /a>
                <br>
            <!-- Old Code, don't use it!
            <a href="redLightOn"><input type="button" value="redLight ON" /a>
            <a href="redLightOff"><input type="button" value="redLight OFF" /a>
            
            <br>

            <a href="yellowLightOn"><input type="button" value="yellowLight ON" /a>
            <a href="yellowLightOff"><input type="button" value="yellowLight OFF" /a>
                
            <br>
            
            <a href="greenLightOn"><input type="button" value="greenLight ON" /a>
            <a href="greenLightOff"><input type="button" value="greenLight OFF" /a>
            -->
            </h4>
            <hr>

        
            <h2><a href="https://github.com/vAnglez/GenCyber-Summer-2022">my GenCyber Project GitHub</a></h2>
        </center>



    </body>
</html>
)=====";
